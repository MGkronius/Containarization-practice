create database ergasia;

use ergasia;
create table ilikia(
user_id int not null auto_increment,
age int ,
primary key(user_id));

use ergasia;
insert into ilikia (user_id,age)  
values (1,20),
       (2,21),
       (3,30),
       (4,26),
       (5,33);