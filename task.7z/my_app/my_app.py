import pymysql

mydb = pymysql.connect(host="localhost", user="root", passwd="root", database="ergasia")

userID = input("dwse user_id")

mycursor = mydb.cursor()

sql = " select age from ilikia where user_id = %s"
mycursor.execute(sql, (userID,))
row = mycursor.fetchone()
print(row)
print('Hello World')